package com.example.lab_with_db;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentValues;
import android.content.res.AssetManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Map;


public class MainActivity extends Activity {
    AssetManager assetManager;
    private static final String DBName = "labIP.db";
    private DBHelper dbHelper;
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.assetManager = getAssets();
    }

    public void createDB(View v) {
        dbHelper = new DBHelper(this, DBName);
        db = dbHelper.getWritableDatabase();
        Log.d("[DEBUG]", "Create DB = " + DBName + "  was created OR Opened the exiting one!");
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public void createTAB(View v) {
        FileHelper fileHelper = new FileHelper(this.assetManager);

        String[] tableNames = fileHelper.readTableNames();
        for (String tableName : tableNames) {
            Map<String, String> columns = fileHelper.readTableStructure(tableName);
            dbHelper.createTable(db, tableName, columns);
        }
    }


    public void fillTables(View v) {
        FileHelper fileHelper = new FileHelper(this.assetManager);
        String[] tableNames = fileHelper.readTableNames();
        for (String tableName : tableNames) {
            String[] columns = fileHelper.readColumns(tableName);
            String[] values = fileHelper.readValues(tableName);
            for (String value : values) {
                String[] valueArray = value.split("\t");
                Log.d("[DEBUG]", "valueArray = " + Arrays.toString(valueArray));
                Log.e("COLUMN", Arrays.toString(columns));
                ContentValues cv = new ContentValues();
                for (int i = 0; i < columns.length; i++) {
                    cv.put(columns[i], valueArray[i]);
                }
                db.insert(tableName, null, cv);
            }
        }
    }

    public void showTables(View v) {
        String[] tableNames = dbHelper.getTableNames(db);
        Log.i("[INFO]", "Table names = " + Arrays.toString(tableNames));

        for (int i = 1; i < tableNames.length; i++) {
            Log.e("TABLE", tableNames[i]);
            dbHelper.readTable(db, tableNames[i]);
        }
    }
}
